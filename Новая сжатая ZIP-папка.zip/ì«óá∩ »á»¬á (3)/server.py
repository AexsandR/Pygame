import requests

api_key = "dda3ddba-c9ea-4ead-9010-f43fbc15c6e3"


def get_image(coordinates: str, z: str, scale: str, map_type: str = "map", *tags) -> bytes:
    params = {
        "ll": coordinates,
        "l": map_type,
        "spn": ','.join([scale, scale]),
        "size": "650,450",
        'z': z,
    }
    print(params)
    test = f'https://static-maps.yandex.ru/1.x/?ll={coordinates}&size=650,450&l={map_type}&z={z}'# я незнаю почему но если делать ссылкой то все рабодае

    tags = [','.join(position) + ',round' for position in tags]
    tags = '~'.join(tags)

    if tags:
        params["pt"] = tags

    url = "http://static-maps.yandex.ru/1.x/"
    try:
        request = requests.get(test)
    except Exception as a:
        print(a)
    'https://static-maps.yandex.ru/1.x/?ll=37.620070,55.753630&size=450,450&l=map&z=0'
    if request.status_code == 200:
        with open("map.png", 'wb') as image:
            image.write(request.content)


def make_get(address: str):
    geocoder_api_server = "http://geocode-maps.yandex.ru/1.x/"

    geocoder_params = {
        "apikey": "40d1649f-0493-4b70-98ba-98533de7710b",
        "geocode": address,
        "format": "json"}

    response = requests.get(geocoder_api_server, geocoder_params)

    if response:
        a = response.json()
        return a


def get_coords(address: str) -> str:
    a = make_get(address)
    return a['response']['GeoObjectCollection']['featureMember'][0]['GeoObject']['Point']['pos'].replace(' ', ',')


def get_post_index(address: str):
    a = make_get(address)

    return a['response']['GeoObjectCollection']['featureMember'][0]['GeoObject']['metaDataProperty'][
        'GeocoderMetaData']['Address']['postal_code']


def get_address(address: str):
    a = make_get(address)

    return a['response']['GeoObjectCollection']['featureMember'][0]['GeoObject']['metaDataProperty'][
        'GeocoderMetaData']['text']


if __name__ == '__main__':
    with open('image.png', 'wb') as image:
        image.write(get_image(get_coords("Красная площадь 1"), "0.002"))
    print("End")
