from server import get_coords, get_image, get_address, get_post_index

import os
import sys

import requests
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QLineEdit, QPushButton, QCheckBox, QRadioButton
from PyQt5.QtWidgets import QButtonGroup
from PyQt5.QtCore import Qt

SCREEN_SIZE = [800, 600]


class Example(QWidget):
    def __init__(self):
        super().__init__()
        # self.getImage()
        self.initUI()
        self.maps_center = '37.530887,55.703118'
        self.spn = '0.002'
        self.address = ''
        self.map = 'map'
        self.z = '17'

    def initUI(self):
        self.setGeometry(100, 100, *SCREEN_SIZE)
        self.setWindowTitle('Отображение карты')

        self.lbl = QLabel("Введите адрес ", self)
        self.lbl.move(50, 20)
        self.lEdit = QLineEdit(self)
        self.lEdit.resize(300, 30)
        self.lEdit.move(50, 50)
        self.btn = QPushButton('Искать', self)
        self.btn.move(380, 50)
        self.btn.clicked.connect(self.coords)
        self.lbl1 = QLabel("", self)
        self.lbl1.move(50, 580)

        self.btn1 = QPushButton("Сброс поискового результата", self)
        self.btn1.move(500, 50)
        self.btn1.resize(self.btn1.sizeHint())
        # self.btn1.clicked.connect(self.reset)

        self.check = QCheckBox('Индекс', self)
        self.check.move(50, 100)
        self.check.stateChanged.connect(self.change_index)

        self.map_file = "map.png"
        self.pixmap = QPixmap(self.map_file)
        self.image = QLabel(self)
        self.image.move(150, 150)
        self.image.resize(400, 400)

        self.rbutton_1 = QRadioButton('Схема', self)
        self.rbutton_1.setChecked(True)
        self.rbutton_1.move(150, 100)

        self.rbutton_2 = QRadioButton('Спутник', self)
        self.rbutton_2.move(250, 100)

        self.rbutton_3 = QRadioButton('Гибрид', self)
        self.rbutton_3.move(350, 100)

        self.button_group = QButtonGroup()
        self.button_group.addButton(self.rbutton_1)
        self.button_group.addButton(self.rbutton_2)
        self.button_group.addButton(self.rbutton_3)
        self.button_group.buttonClicked.connect(self.button_clicked)

    def button_clicked(self, button):
        a = button.text()
        if a == 'Схема':
            self.map = "map"
        elif a == 'Спутник':
            self.map = 'sat'
            if self.z > '19':  # после 19 не увеличивает
                self.z = "19"
        else:
            self.map = 'skl'
        self.maps_center = get_coords(self.address)
        get_image(self.maps_center, self.z, self.spn, self.map)
        self.show_image()

    def change_index(self):
        a = get_address(self.address)
        b = get_post_index(self.address)
        if self.check.isChecked():
            self.lbl1.setText(f"{b}, {a}")
        else:
            self.lbl1.setText(f"{a}")
        self.lbl1.resize(self.lbl1.sizeHint())

    def keyPressEvent(self, event):
        if self.map == 'sat':
            if event.key() == Qt.Key_PageUp and self.z != '19':  # после 19 не увеличивает
                self.z = str(int(self.z) + 1)
                get_image(self.maps_center, self.z, self.spn, self.map)
                self.show_image()
        elif event.key() == Qt.Key_PageUp and self.z != '22':
            self.z = str(int(self.z) + 1)
            get_image(self.maps_center, self.z, self.spn, self.map)
            self.show_image()
        if self.map == 'skl':
            if event.key() == Qt.Key_PageUp and self.z != '0':  # после 19 не увеличивает
                self.z = str(int(self.z) - 1)
                get_image(self.maps_center, self.z, self.spn, self.map)
                self.show_image()
        elif event.key() == Qt.Key_PageDown and self.z != '0':
            self.z = str(int(self.z) - 1)
            get_image(self.maps_center, self.z, self.spn, self.map)
            self.show_image()

    def show_image(self):
        self.map_file = "map.png"
        self.pixmap = QPixmap(self.map_file)
        self.image.setPixmap(self.pixmap)

    def coords(self):
        self.address = self.lEdit.text()
        self.maps_center = get_coords(self.address)
        get_image(self.maps_center, self.z, self.spn, self.map)
        self.show_image()
        self.lbl1.setText(get_address(self.address))
        self.lbl1.resize(self.lbl1.sizeHint())

    def closeEvent(self, event):
        """При закрытии формы подчищаем за собой"""
        os.remove(self.map_file)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Example()
    ex.show()
    sys.exit(app.exec())
